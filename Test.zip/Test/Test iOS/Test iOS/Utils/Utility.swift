import Foundation

class SwiftBasics {
    func sumOfEvenNumbers(in numbers: [Int]) -> Int {
        var sum = 0
        for number in numbers {
            if number % 2 == 0 {
                sum += number
            }
        }
        return sum
    }
}
