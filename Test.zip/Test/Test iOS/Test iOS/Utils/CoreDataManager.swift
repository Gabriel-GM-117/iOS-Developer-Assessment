
import Foundation
import UIKit
import CoreData
/*
class CoreDataManager {
    static let shared = CoreDataManager()
    
    lazy var persistentContainer: NSPersistentContainer = {
        let container = NSPersistentContainer(name: "ProductModel")
        container.loadPersistentStores(completionHandler: { (storeDescription, error) in
            if let error = error as NSError? {
                fatalError("Unresolved error \(error), \(error.userInfo)")
            }
        })
        return container
    }()
    
    var context: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    func saveContext() {
        if context.hasChanges {
            do {
                try context.save()
            } catch {
                let nserror = error as NSError
                fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
            }
        }
    }
}


class LocalDataManager {
    static let shared = LocalDataManager()
    
    func saveProductsToCoreData(products: [Product]) {
        let context = CoreDataManager.shared.context
        
        for product in products {
            let productEntity = ProductEntity(context: context)
            productEntity.id = Int32(product.id ?? 0)
            productEntity.title = product.title
            productEntity.price = product.price ?? 0.0
            // Set other attributes
            
            CoreDataManager.shared.saveContext()
        }
    }
    
    func loadProductsFromCoreData() -> [Product] {
        let context = CoreDataManager.shared.context
        
        let fetchRequest: NSFetchRequest<ProductEntity> = ProductEntity.fetchRequest()
        
        do {
            let productEntities = try context.fetch(fetchRequest)
            let products = productEntities.map { Product(id: Int($0.id), title: $0.title, price: $0.price, category: $0.category, description: $0.description, image: $0.image) }
            return products
        } catch {
            print("Error loading data from Core Data: \(error.localizedDescription)")
            return []
        }
    }
}
*/
