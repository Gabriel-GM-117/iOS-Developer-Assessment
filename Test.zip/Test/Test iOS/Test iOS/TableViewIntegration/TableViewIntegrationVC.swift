import Foundation
import UIKit


class TableViewIntegrationVC: UIViewController {

    
    @IBOutlet weak var tableView: UITableView!
    
    var dataModel: [Product] = []
    var servicesManager = ServicesManager()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        servicesManager.delegate = self
        tableView.dataSource = self
        tableView.delegate = self
        servicesManager.showList()

    }

}

// MARK: - Delegado Pokemon
extension TableViewIntegrationVC: ServicesManagerDelegate {
    func showListProduct(list: [Product]) {
        dataModel = list
        
        DispatchQueue.main.async {
            self.tableView.reloadData()
        }
    }
    
    
}
extension TableViewIntegrationVC: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataModel.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Subtitle", for: indexPath)
        
        let product = dataModel[indexPath.row]
        cell.textLabel?.text = product.title
        cell.detailTextLabel?.text = "$\(product.price ?? 0.0)"
        
        return cell
    }
    
}
