

import Foundation

protocol ServicesManagerDelegate {
    func showListProduct(list: [Product])
}

struct ServicesManager {
    var delegate: ServicesManagerDelegate?
    
    func showList() {
        let urlString = "https://fakestoreapi.com/products"
        
        if let url = URL(string: urlString) {
            let session = URLSession(configuration: .default)
            
            let task = session.dataTask(with: url) { data, response, error in
                if let error = error {
                    print("Error al obtener datos de la API: ", error.localizedDescription)
                    return
                }
                
                if let safeData = data {
                    if let listProduct = self.parsearJSON(productData: safeData) {
                        print("Lista Productos: ", listProduct)
                        
                        self.delegate?.showListProduct(list: listProduct)
                    }
                }
            }
            
            task.resume()
        }
    }
    
    func parsearJSON(productData: Data) -> [Product]? {
        let decodificador = JSONDecoder()
        do {
            let datosDecodificados = try decodificador.decode([Product].self, from: productData)
            return datosDecodificados
        } catch let decodingError {
            print("Error al decodificar los datos: ", decodingError)
            return nil
        }
    }
}

extension Data {
    func parseData(quitarString str: String) -> Data? {
        let dataAsString = String(data: self, encoding: .utf8)
        let parseDataString = dataAsString?.replacingOccurrences(of: str, with: "")
        guard let data = parseDataString?.data(using: .utf8) else { return nil }
        return data
    }
}
