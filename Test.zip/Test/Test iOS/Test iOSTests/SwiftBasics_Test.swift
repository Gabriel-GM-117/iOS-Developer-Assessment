import XCTest
@testable import Test_iOS

final class SwiftBasics_Test: XCTestCase {

    var sut = SwiftBasics()
    
    override func setUpWithError() throws {
        // Put setup code here. This method is called before the invocation of each test method in the class.
    }

    override func tearDownWithError() throws {
        // Put teardown code here. This method is called after the invocation of each test method in the class.
    }

    func test_sumOfEvenNumbers() throws {
        var expetNumber = 6
        let result = sut.sumOfEvenNumbers(in: [1,2,3,4,5])
        XCTAssertTrue(result == expetNumber)
    }
    
    
   

}
