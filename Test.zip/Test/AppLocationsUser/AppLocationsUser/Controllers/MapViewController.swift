import UIKit
import MapKit

class MapViewController : UIViewController, MKMapViewDelegate{
    
    @IBOutlet weak var map: MKMapView!
    var UserSelected : User?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        self.map.delegate = self
        // Do any additional setup after loading the view.
        addAnotation()
    }
    
    func addAnotation()
    {
        if let user = UserSelected{
            
            let startPosition = CLLocationCoordinate2D(latitude: Double(user.address.geolocation.lat)!, longitude: Double(user.address.geolocation.long)!)
            let region = MKCoordinateRegion(center: startPosition, latitudinalMeters: 100000, longitudinalMeters: 100000)
            map.setRegion(region, animated: true)
            
            let anotation = MKPointAnnotation()
            anotation.title = user.name.firstname + " " + user.name.lastname
            anotation.coordinate = CLLocationCoordinate2D(latitude:  Double(user.address.geolocation.lat)!, longitude: Double(user.address.geolocation.long)!)
            map.addAnnotation(anotation)
        }
    }
}
