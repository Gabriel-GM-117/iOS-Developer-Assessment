import Foundation

struct User : Codable{
    let email: String?
    let address:Address
    let name : UserName
}
struct Address: Codable {
    let geolocation : Geolocation
    
}

struct UserName: Codable{
    let firstname: String
    let lastname : String
}

struct Geolocation: Codable{
    let lat: String
    let long: String
}

typealias UserModel = [User]
