import UIKit


class ViewController: UIViewController {

    var userArray : [User] = []
    @IBOutlet weak var tablewView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        getUsers()
    }

    func getUsers(){
        let urlString = "https://fakestoreapi.com/users"
        let urlSesion = URLSession.shared
        if let url = URL(string: urlString){
            urlSesion.dataTask(with: url){ data, response, error in
                if let data = data{
                    do{
                         let res = try JSONDecoder().decode(UserModel.self, from: data)
                            print(res)
                        DispatchQueue.main.async {
                            self.userArray = res
                            self.tablewView.reloadData()
                        }
                        
                    }
                        catch let errorD {
                            print(errorD)
                        }
                }
                    
                    
            }.resume()
        }
       
    }
}

extension ViewController : UITableViewDelegate, UITableViewDataSource
{
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return userArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = UITableViewCell()
        
             cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
            cell.textLabel?.text = self.userArray[indexPath.row].name.firstname
        
       
       
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        print("celda seleccionada")
        
        let storyboard = self.storyboard?.instantiateViewController(withIdentifier: "MapViewController") as! MapViewController
        storyboard.UserSelected = self.userArray[indexPath.row]
        self.navigationController?.pushViewController(storyboard, animated: true)
        
    }
}

